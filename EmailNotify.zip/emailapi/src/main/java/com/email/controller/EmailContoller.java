package com.email.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.email.model.EmailRequest;
import com.email.service.EmailService;

@RestController
public class EmailContoller {
	
	@Autowired
	private EmailService emailService;
	
	@RequestMapping("/welcome")
	public String welcome() {
		return "hello this is email api";
	}
	
	@RequestMapping(value="/sendemail1",method=RequestMethod.POST)
	public ResponseEntity<?> sendEmail1(@RequestBody EmailRequest request)
	{
		
		System.out.println(request);
		boolean res=this.emailService.sendEmail("Cart Item Price Changed!!!",request.getMessage(),request.getTo());
		if(!res)
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Email Not Sent");
		return ResponseEntity.ok("Email is sent....");
		
		
	}
	@RequestMapping(value="/sendemail2",method=RequestMethod.POST)
	public ResponseEntity<?> sendEmail2(@RequestBody EmailRequest request)
	{
		
		System.out.println(request);
		boolean res=this.emailService.sendEmail("New Price Available!!!",request.getMessage(),request.getTo());
		if(!res)
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Email Not Sent");
		return ResponseEntity.ok("Email is sent....");
		
		
	}
	@RequestMapping(value="/sendemail3",method=RequestMethod.POST)
	public ResponseEntity<?> sendEmail3(@RequestBody EmailRequest request)
	{
		
		System.out.println(request);
		boolean res=this.emailService.sendEmail("Ordered Items Delivered!!",request.getMessage(),request.getTo());
		if(!res)
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Email Not Sent");
		return ResponseEntity.ok("Email is sent....");
		
		
	}

}
